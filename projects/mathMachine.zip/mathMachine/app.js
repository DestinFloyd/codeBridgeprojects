// making sure its connected : console.log("working")


// now the plan. Make it when you hit a button it goes into an array. 
// they keys are functions
// clear clears the array.
//  happy coding!
// console.log("item before")
// console.log(document.getElementById('display').value);
// console.log("item after")
















// var a = " ";
// var b;
// var c = " ";
// var d;
// var input =[];
// var res = "";

// var zero = () => {
//     a + "0";
//     input += "0"
//     document.getElementById('display').value = document.getElementById('display').value + "0";
//     console.log(document.getElementById('display').value);
//     console.log(a);
    
//     } 


// var one = () => {
// a + "1";
// input +=1;
// document.getElementById('display').value = document.getElementById('display').value + "1";
// console.log(document.getElementById('display').value);
// console.log(a);

// }

// var add = () =>{
//     a += " + "
//     input += " + ";
//     document.getElementById('display').value = document.getElementById('display').value + " + ";

// }


//  var equal = () =>{
//      console.log(input.split(" "));
//      c = input.split(" ");
//      for(let i = 0; i < c.length; i ++){
//       var  galaxy = " ";
//       galaxy = (+ c[i]);
//      }
//      eval(galaxy);
//      document.getElementById('display').value = document.getElementById('display').value = eval(galaxy);
// }

    
    // console.log(eval(res));
    // console.log(input);
    // eval(input);



// var equals = () =>
// { res = input.split();
//     return input.split();
//     console.log(eval(res));
//     console.log(input);
//     eval(input);

// }














// b = eval(input);
// document.getElementById("equB").value = b;

// var res = string.split();
// console.log(res);

// var new = res[0];
// console.log(new)

// let z = res;

// console.log(z);












// var onee;
// var inputed = [];
// var x ;

// var one = () =>{

//    x = document.getElementById("display").value;
//    x = x +=1;

// }
//     var oneA = () =>
//     onee = math.display.value += '1';
//     inputed.push(onee)

// }
// var math = () => {
//     setValues();
//     z = a + b;
//     document.getElementById('display').value = z;
    
    
//     }
// console.log(inputed);



















// var a;
// var b;
// var c;
// var z;

// var setValues = () => {
//     a = Number(document.getElementById("spot1").value);
//     b = Number(document.getElementById("spot2").value);
//     c = Number(document.getElementById("spot11").value);
    
// }

// var math = () => {
// setValues();
// z = a + b;
// window.alert(z)

// }










// var spot1 = [9, 8, 17];
// var sum;
// let x;
// var addition = (x) => {
    
// for (let i = (x.length); i >= 0; x.pop()){
//     sum= sum += (x[i]);
//     // console.log(sum);
// }


//     let i = (array.length);
//     while (i > -1) {
//         sum = (spot1[0]+= spot1[i]);
//         spot1.pop();
//     }
//     { return sum};
// }
// console.log(sum);
// console.log(spot1);
// console.log(addition);


// for(let owed ; owed > 0; owed -- ){
//     if(quarter > 0);
//    }
   
//    for(quarter; quarter > 0; quarter --){
      
//       console.log(quarter, "give quarter") ;
   //    console.log("give quarter");
//    };
//    addition(spot1);




